AIRLINE TICKET RESERVATION & MANAGEMENT SYSTEM
ব্যবহার নির্দেশিকা (বাংলা)

সর্বশেষ পরিবর্তন:
- Cancel করা Booking আর Active E-ticket হিসেবে দেখাবে না।
- View My Bookings-এ Confirmed ও Cancelled Booking আলাদা দেখাবে।
- Cancelled Booking-এর জন্য স্পষ্ট CANCELLED card দেখাবে; পুরোনো Ticket আর দেখাবে না।
- Cancel করার পর সেই Flight/Date-এর Seat আবার Available হবে।
- Flight Option ও E-ticket মাঝখানে সুন্দর Card Layout-এ দেখাবে।
- Project-এর নাম শুধু প্রথম Welcome Screen-এ দেখাবে; প্রতিটি Menu-তে পুনরায় নয়।
- Source Code থেকে ব্যাখ্যামূলক Comment এবং অপ্রয়োজনীয় #define সরানো হয়েছে; প্রয়োজনীয় ৫টি Header রাখা হয়েছে।

============================================================
১. এই সংস্করণে কী কী আছে
============================================================
১) User account Registration ও Login
২) Bangladesh-এর ৮টি বিমানবন্দর থেকে From ও To নির্বাচন
৩) নিজের পছন্দমতো ভবিষ্যতের Travel Date দেওয়া
৪) Route ও Date অনুযায়ী demo flight time/fare দেখা
৫) Flight নির্বাচন ও seat availability দেখা
৬) একটি account দিয়ে নিজের/পরিবারের একাধিক passenger-এর ticket বুক করা
৭) Adult ও Child আলাদা fare
৮) প্রতিটি passenger-এর নাম, বয়স ও আলাদা seat number
৯) মোট ভাড়া, ৫% service charge এবং fare summary
১০) Cash at counter / bKash demo / Nagad demo / Card demo payment option
১১) E-ticket, নিজের booking দেখা ও বাতিল
১২) Admin দিয়ে custom demo flight template যোগ/পরিবর্তন/বন্ধ করা
১৩) Admin দিয়ে সব booking দেখা ও cancel করা
১৪) File handling দিয়ে data save করা

গুরুত্বপূর্ণ: এটি একটি শিক্ষামূলক C project. লাইভ airline schedule, live seat inventory,
real ticket price, online payment বা airline server-এর সঙ্গে এটি সংযুক্ত নয়। Built-in
flight number, time ও fare কেবল demonstration data. ৮টি Airport choice দেখালেও
প্রতিটি airport pair-এ বাস্তবে প্রতিদিন flight চলে—এমন নিশ্চয়তা এই project দেয় না।

============================================================
২. Airport List (Menu-তে যে Number দিতে হবে)
============================================================
1 = Dhaka (DAC) - Hazrat Shahjalal International Airport
2 = Chattogram (CGP) - Shah Amanat International Airport
3 = Sylhet (ZYL) - Osmani International Airport
4 = Cox's Bazar (CXB) - Cox's Bazar Airport
5 = Rajshahi (RJH) - Shah Makhdum Airport
6 = Jashore (JSR) - Jashore Airport
7 = Saidpur (SPD) - Saidpur Airport
8 = Barishal (BZL) - Barishal Airport

============================================================
৩. VS Code-এ Compile ও Run
============================================================
১) main.c ফাইলটি একটি আলাদা project folder-এ রাখো।
২) VS Code-এ সেই folder Open করো।
৩) Terminal > New Terminal খোলো।
৪) নিচের Compile Command দাও:

   gcc -std=c11 -Wall -Wextra -Wpedantic main.c -o airline.exe

৫) Compile error না থাকলে Run করো:

   .\airline.exe

MSYS2 UCRT64 Terminal ব্যবহার করলে Run command:

   ./airline.exe

GCC Compiler install ও PATH configure না থাকলে আগে সেটি ঠিক করতে হবে।

============================================================
৪. প্রথমবার কীভাবে User Account খুলবে
============================================================
Main Menu:
1. User section
2. Admin section
3. Exit

প্রথমবার এইভাবে দাও:
Main Menu-তে 1
User Section-এ 1 (Register new account)
তারপর উদাহরণ হিসেবে:
Full name: Shreya Das
Create username: shreya01
Create password: pass123
Confirm password: pass123
Contact phone number: নিজের test/demo number লিখবে

Registration শেষে Enter চাপবে। এরপর User Section-এ 2 দিয়ে Login করো:
Username: shreya01
Password: pass123

নোট: বাস্তব বা গুরুত্বপূর্ণ password ব্যবহার করবে না। এই শিক্ষামূলক প্রোগ্রামে password
local data file-এ plain text-এর মতো সংরক্ষিত হয়; এটি production-security system নয়।

============================================================
৫. Flight Search কীভাবে করবে
============================================================
Login করার পরে User Dashboard-এ:
1. Search flights
2. Book flight (single or family)
3. View my bookings / e-ticket
4. Cancel my booking
5. Logout

Search flights-এর উদাহরণ:
From airport number: 1        (Dhaka)
To airport number: 2          (Chattogram)
Travel date: 2027-01-15        (ভবিষ্যতের তারিখ, YYYY-MM-DD format)

প্রোগ্রাম ৩টি built-in demo time option দেখাবে:
08:00 - 09:00
13:30 - 14:30
18:00 - 19:00

প্রতিটি route/date-এ seat availability, demo flight code এবং demonstration fare দেখাবে।
এই সময় ও ভাড়া বাস্তব airline-এর confirmed schedule/fare নয়।

============================================================
৬. Single বা Family Booking করার সম্পূর্ণ উদাহরণ
============================================================
ধরা যাক: ১ জন Adult + ১ জন Child-এর ticket বুক করবে।

Main Menu: 1
User Section: 2 (Login)
Username: shreya01
Password: pass123
User Dashboard: 2 (Book flight)
From: 1 (Dhaka)
To: 2 (Chattogram)
Travel date: 2027-01-15
Choose flight option: 1
Number of adults: 1
Number of children: 1

Adult passenger:
Passenger full name: Adult Passenger
Age: 30
Choose seat: 1

Child passenger:
Passenger full name: Child Passenger
Age: 8
Choose seat: 2

Payment choice:
1 = Airport counter
2 = bKash (simulated)
3 = Nagad (simulated)
4 = Card (simulated)

উদাহরণে 2 দিলে bKash Demo দেখাবে। Y দিলে booking confirm হবে।

Passenger rule:
Adult = 12 বছর বা তার বেশি
Child = 2 থেকে 11 বছর
একটি family booking-এ কমপক্ষে ১ জন Adult থাকতে হবে।
একটি Booking-এ সর্বোচ্চ ৬ জন passenger রাখা যাবে। ২ বছরের কম infant এই version-এ
include করা হয়নি।

গুরুত্বপূর্ণ: প্রত্যেক passenger-এর আলাদা নাম, বয়স ও seat number দিতে হবে, কিন্তু
প্রত্যেকের আলাদা User Account বা Login Registration লাগবে না। একজন registered user
তার family-র জন্য একসঙ্গে booking করতে পারবে।

============================================================
৭. Fare Calculation কীভাবে হয়
============================================================
এই project-এর demo rule:
Adult fare = selected flight-এর base fare
Child fare = Adult base fare-এর ৭৫%
Service charge = সব passenger fare-এর যোগফলের ৫%
Total = Subtotal + Service charge

উদাহরণ (adult base fare যদি 3550 BDT হয়):
১ Adult = 3550.00 BDT
১ Child = 2662.50 BDT
Subtotal = 6212.50 BDT
5% Service charge = 310.62 BDT (rounded display)
Total = 6523.12 BDT

এই child discount ও service charge project-এর নিজস্ব sample rule; কোনো নির্দিষ্ট airline-এর
প্রকাশিত fare policy নয়।

============================================================
৮. Payment Option-এর অর্থ
============================================================
1. Airport counter: Payment status হবে PAY AT COUNTER.
2. bKash Demo: SIMULATED ONLY.
3. Nagad Demo: SIMULATED ONLY.
4. Card Demo: SIMULATED ONLY.

এখানে কোনো টাকা কাটা হয় না। Real bKash/Nagad PIN, OTP, card number বা CVV চাইবে না;
প্রোগ্রাম এসব তথ্য নেওয়ার জন্য তৈরি করা হয়নি। Payment choice কেবল demonstration।

============================================================
৯. E-ticket / Booking ID কীভাবে ব্যবহার করবে
============================================================
Booking confirm হলে একটি Booking ID দেখাবে, যেমন 3001.
User Dashboard > 3 দিয়ে নিজের booking list দেখবে। Confirmed booking থাকলে Y দিয়ে Booking ID
দিয়ে E-ticket দেখা যাবে। Cancelled booking-এর ক্ষেত্রে E-ticket দেখাবে না; বরং CANCELLED
card এবং “YOUR BOOKING IS CANCELLED” বার্তা দেখাবে।
User Dashboard > 4 দিয়ে নিজের Booking ID দিয়ে booking cancel করা যাবে। Cancel করলে
এই demo program-এ ঐ booking-এর seat আবার available হবে। পরবর্তীবার Login করলেও Cancelled
status সংরক্ষিত থাকবে।

একটি family booking-এ সব passenger একই Booking ID-এর অধীনে থাকবে; প্রত্যেকের seat আলাদা।

============================================================
১০. Admin Login ও Flight Management
============================================================
Demo Admin Username: admin
Demo Admin Password: admin123

Main Menu > 2 (Admin section)

Admin Dashboard:
1. Manage flights
2. Manage booking records
3. Logout

Manage flights-এ:
1. View admin-added flight templates
2. Add flight template
3. Update flight template
4. Deactivate flight template
5. Back

Admin-added template-এ Flight Number, From airport, To airport, Departure, Arrival,
Seat count এবং Adult base fare দিতে হয়। এটি demo timetable template; selected route-এ
ব্যবহারকারীর দেওয়া future date-এ option হিসেবে দেখাবে। এটি real airline schedule নয়।

Manage booking records-এ সব booking দেখা এবং Booking ID দিয়ে cancel করা যায়।

============================================================
১১. Data File কোথায় থাকবে
============================================================
প্রোগ্রাম যে folder থেকে run হবে, সেই folder-এ নিচের file তৈরি হবে:
users_v2.dat          = user account information
bookings_v2.dat       = booking and passenger information
custom_flights_v2.dat = admin-added flight templates

এই data file-গুলো মুছে ফেললে saved account/booking/template data হারিয়ে যাবে।

============================================================
১২. Practice / Teacher Demonstration Checklist
============================================================
[ ] Program চালিয়ে Main Menu দেখানো
[ ] নতুন User Registration করা
[ ] User Login করা
[ ] Dhaka থেকে Chattogram route search করা
[ ] Future date দেওয়া এবং ৩টি time option দেখানো
[ ] এক Adult-এর single booking করা
[ ] Adult + Child family booking করা
[ ] একই flight/date-এ seat availability কমেছে দেখানো
[ ] Booking ID দিয়ে e-ticket দেখা
[ ] Booking cancel করে seat আবার available হওয়া দেখানো
[ ] Admin Login করা
[ ] Admin দিয়ে custom flight template add করা
[ ] Admin দিয়ে সব booking দেখা
[ ] Admin দিয়ে একটি booking cancel করা

============================================================
১৩. Project-এর সীমাবদ্ধতা
============================================================
- Live airline timetable/API ব্যবহার করা হয়নি।
- সব airport pair-এ বাস্তব scheduled route আছে—এমন দাবি করা হচ্ছে না।
- Fare এবং child discount demonstration value/rule.
- Payment gateway বা real money transaction নেই।
- Database server নেই; local binary file ব্যবহৃত হয়েছে।
- User password secure hashing/encryption করা হয়নি; তাই real password ব্যবহার করা যাবে না।
- Infant (২ বছরের কম) booking এই version-এ নেই।

এই সীমাবদ্ধতাগুলো report ও presentation-এ পরিষ্কারভাবে বলা উচিত।
